package com.selenium;
//Q:Check if given string is anagram or Not 
import java.util.Arrays;
import java.util.Map;

public class Angm {
	
	
	public boolean isAnagram(String s1, String s2) {
        // If the lengths are different, they cannot be anagrams.
        if (s1.length() != s2.length()) {
            return false;
        }

        // Convert both strings to character arrays.
        char[] charArray1 = s1.toCharArray();
        char[] charArray2 = s2.toCharArray();

        // Sort both character arrays.
        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        // If the sorted arrays are equal, the strings are anagrams.
        return Arrays.equals(charArray1, charArray2);
    }

    public static void main(String[] args) {
    	Angm sol = new Angm();

        String str1a = "listen";
        String str1b = "silent";
        System.out.println("\"" + str1a + "\" and \"" + str1b + "\" are anagrams: " + sol.isAnagram(str1a, str1b)); // Output: true

        String str2a = "hello";
        String str2b = "world";
        System.out.println("\"" + str2a + "\" and \"" + str2b + "\" are anagrams: " + sol.isAnagram(str2a, str2b)); // Output: false

       
    }


}
