package com.selenium;


import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

//Check chrome options 
public class TestUI {
	static WebDriver driver;
	
	@Test
	public static void m1()
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\EclipseWorkplace\\SeleniumHandsOn\\Resources\\chromedriver.exe");
		ChromeOptions options=new ChromeOptions();
		
		options.addArguments("--disable-blink-features=AutomationControlled");
		options.addArguments("--disable-notifications");
		options.addArguments("--start-maximized");
		WebDriver driver=new ChromeDriver(options);
		driver.get("https://www.makemytrip.com/");
		//driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	
	WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10));
	
	WebElement closepopup=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@data-cy='closeModal']")));
	closepopup.click();
	
	driver.findElement(By.xpath("//input[@data-cy='toCity']")).click();
	
	List<WebElement> todropdown=driver.findElements(By.xpath("//p[@class='font14 appendBottom5 blackText']"));
	
	
	
	
	for(WebElement p:todropdown)
	{
		String t=p.getText();
		
		System.out.println(t);
		
	}
	
	
	
		
		
	}

}
