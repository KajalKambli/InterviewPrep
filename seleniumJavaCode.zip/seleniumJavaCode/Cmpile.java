package com.selenium;
// Q : Interviewer want to check you know Oops concepts 

public class Cmpile extends Yup
{

	public int  m(int a)
    {
        return a;
        
    }
    
    public String m(String b){
        
        
        return b;
        
    }
    
    
    
    public static void main(String[] args) {
        
    	Cmpile ob=new Cmpile();
    	
    	System.out.println(ob.m1(3));
        
    }
}
