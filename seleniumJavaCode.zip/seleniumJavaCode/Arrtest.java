package com.selenium;

//Q:Shift zeros at end -->[9, 8, 1, 0, 0]

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Arrtest {

	public static void main(String[] args) {
		
		//Integer[]
		Integer[] s={0,1,9,8,0};
		
		Arrays.sort(s,Collections.reverseOrder());
		
		System.out.println(Arrays.toString(s));    

		
		//int[]
		
		 int[] it={1,2,3,4,3,2,5,1};
	     Arrays.sort(it);
	     
	     List<Integer> ls=Arrays.stream(it).boxed().collect(Collectors.toList());
	     
	     
	     
	     Collections.reverse(ls);
	     
	}

}
