package com.selenium;
//Q: check if string is palindrome 
public class palindrom {
	
    public boolean isPalindrome(String s) 
    {
       
    	String s1=s.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
    	
    	System.out.println(s1);
    	if (s1 == null || s1.isEmpty()) {
            return true;
        }

        int left = 0;
        int right = s1.length() - 1;

        while (left < right) {
           
        

            // Compare the characters (ignoring case)
            if (s1.charAt(left) != s1.charAt(right)) {
                return false;
            }

            left++;
            right--;
        }

        return true;
    }

    public static void main(String[] args) {
    	palindrom solution = new palindrom();

        String s1 = "racecar";
        System.out.println("\"" + s1 + "\" is a palindrome: " + solution.isPalindrome(s1)); // Output: true

        String s2 = "A man, a plan, a canal: Panama";
        System.out.println("\"" + s2 + "\" is a palindrome: " + solution.isPalindrome(s2)); // Output: true

        String s3 = "a1a";
        System.out.println("\"" + s3 + "\" is a palindrome: " + solution.isPalindrome(s3)); // Output: false

        String s4 = " ";
        System.out.println("\"" + s4 + "\" is a palindrome: " + solution.isPalindrome(s4)); // Output: true

        String s5 = "0P";
        System.out.println("\"" + s5 + "\" is a palindrome: " + solution.isPalindrome(s5)); // Output: false
    }

}
