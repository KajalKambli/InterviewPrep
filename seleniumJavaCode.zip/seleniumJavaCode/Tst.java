package com.selenium;

import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;



public class Tst {

	
	public static void main(String[] args) {
		
		String k="Hi   I am       kajal and       I   am        an   AQA";
		//StringBuilder s=new StringBuilder(k);
		
		String[] S=k.split("");
		
		//String it=String.Join(S);
		
		//System.out.println(it);
		
		//String p=S.toString();
		
		//System.out.println(result);
		
	
		//reverse the sorted string 
		Integer Arr[]={0,0,3,5,7,8,10};
		
		Arrays.sort(Arr,Collections.reverseOrder());
		// TODO Auto-generated method stub
		
		
		System.out.println(Arrays.toString(Arr));

	}

}
