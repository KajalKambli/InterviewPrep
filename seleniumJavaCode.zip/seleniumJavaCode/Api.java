package com.selenium;
// Shift non zeros elements without using sort function  at end and zeros to start out put -->[0, 0, 0, 0, 1, 5, 8]
import java.util.Arrays;

public class Api {
	
public static void main(String[] args)
{
	
	 int[] in={0,1,0,5,8,0,0};
     int read =in.length-1;
     int write =in.length-1;
     
     while(read>0)
     {
         if(in[read]!=0)
         {
             in[write]=in[read];
             
            
             write--;
             
         }
         read--;
     }
     while(write>0)
     
     {
        in[write]=0; 
         write--;
     }
     
     System.out.println(Arrays.toString(in));


}
}
