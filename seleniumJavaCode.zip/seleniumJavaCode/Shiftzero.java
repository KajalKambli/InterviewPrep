package com.selenium;

import java.util.Arrays;

public class Shiftzero {

	public static void main(String[] args) {
		Integer[] arr = {7, 0, 9, 0, 0, 1, 3, 0, 8, 7};
        
        // Output: [0, 0, 0, 0, 7, 9, 1, 3, 8, 7]
    

    
        if (arr == null || arr.length <= 1) {
            return;
        }

        int writeIndex = arr.length - 1;
        for (int readIndex = arr.length - 1; readIndex >= 0; readIndex--) {
            if (arr[readIndex] != 0) {
                arr[writeIndex] = arr[readIndex];
                writeIndex--;
            }
        }

        while (writeIndex >= 0) {
            arr[writeIndex] = 0;
            writeIndex--;
        }
        
        System.out.println(Arrays.toString(arr));
	}
}
