package com.selenium;

public class javatets extends Strut{
	
	//inherit class and concat string without using third string 

	public static void main(String[] args) {
		
		Strut stob=new Strut();
		
		String sr1="kajal";
		String sr2="kambli";
		
		System.out.println(stob.concat(sr1, sr2));
		
		System.out.println(stob.removedup(stob.concat(sr1, sr2)));
		System.out.println(stob.sortar(stob.concat(sr1, sr2)));
		
		
		// TODO Auto-generated method stub

	}

}
