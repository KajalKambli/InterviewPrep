package com.selenium;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;


public class Reversetest {

	
	
	public static void main(String[] args) {
		
		String K="Pranil Kajal";
		//System.out.println(K.concat(K));
		
		StringBuffer str=new StringBuffer(K);
		//str.replace("P");
		str.reverse();
		
				//str.append(K);
			
				
//				System.out.println(str.length());	
     System.out.println(""+str);
				
     int[] it={1,2,3,4,3,2,5,1};
     Arrays.sort(it);
     
     List<Integer> ls=Arrays.stream(it).boxed().collect(Collectors.toList());
     
     
     
     Collections.reverse(ls);
     
     System.out.println(ls);
     
     int n=it.length;
     
     
     
     String[] str1=Arrays.toString(it).split("[\\[\\]]")[1].split(", ");
     
     //concate 2 arrays 
     Integer[] it4={1,2,3};
     
     Integer[] it2={4,5,6};
     
     Integer[] it3=Stream.concat(Arrays.stream(it4),Arrays.stream(it2)).toArray(Integer[]::new);
     
    

	}

}
