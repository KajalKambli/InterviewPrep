package com.selenium;

import java.util.Arrays;

public class Strut {
	
	
	public String concat(String s1, String s2)
	{
		String s3=s1.concat(s2);
		
		return s3;
		
		
	}
	
	public String removedup(String s4)
	
	{
		
		String[] str1=s4.split("");
		
		String Str2="";
		
		for(int i=0; i<str1.length;i++)
		{
			
			if(!Str2.contains(str1[i]))
			{
				
				Str2+=str1[i];
			}
		}
		
		return Str2;
		
	}
	
	public char[] sortar(String s5)
	{
		
		char[] ch=s5.toCharArray();
		
		Arrays.sort(ch);
		
		return ch;
		
		
	}

}




