package com.selenium;

public class Stngmethd {

	public static void main(String[] args) {
	//update string 	
		
		String s1="mYrule";
		
		StringBuilder sb=new StringBuilder(s1);
		sb=sb.insert(2, "Own");
		
		System.out.println(sb);
		// TODO Auto-generated method stub

	}

}
