
package com.selenium;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.io.Files;

public class HandsOn {

	
	public static void main(String[] args) throws InterruptedException, IOException {
		// Initialize the Chrome driver Driver 
		System.setProperty("webdriver.chrome.driver", "C:\\EclipseWorkplace\\SeleniumHandsOn\\Resources\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		// take screenshots
		File file=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(file, new File("C:\\EclipseWorkplace\\SeleniumHandsOn\\OutPut\\screenshot.png"));
		
		//load excel file and cell data 
		FileInputStream file2=new FileInputStream("C:\\EclipseWorkplace\\SeleniumHandsOn\\OutPut\\output.xlsx");
		@SuppressWarnings("resource")
		XSSFWorkbook wb=new XSSFWorkbook(file2);
		XSSFSheet sheet=wb.getSheetAt(0);
	
		XSSFCell dta=sheet.getRow(0).getCell(0);
		System.out.println("data is "+dta);
	
		
		
		
		
		//Wait1
		Thread.sleep(200);
		
		//Implicit wait syntax
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//Explicit wait	syntax
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.id("//a[@data-cy='home-hero-pricing']")));

		//Declare and initialize a fluent wait
		FluentWait<WebDriver> wait1 = new FluentWait<WebDriver>(driver);
		//Specify the timeout of the wait
		wait1.withTimeout(Duration.ofSeconds(20));
		//Specify polling time
		wait1.pollingEvery(Duration.ofSeconds(20));
		//Specify what exceptions to ignore
		wait1.ignoring(NoSuchElementException.class);

		//This is how we specify the condition to wait on.
		//This is what we will explore more in this chapter
		wait1.until(ExpectedConditions.alertIsPresent());
		
	
		WebElement element=driver.findElement(By.xpath("//a[@data-cy='home-hero-pricing']"));
		WebElement element2=driver.findElement(By.xpath("//a[@data-cy='home-hero-pricing']"));
		// declare action class
		Actions ac=new Actions(driver);
		
		//right click on element 
        ac.contextClick(element);
        
        
        //move to element 
        ac.moveToElement(element);
        
        ac.dragAndDrop(element, element2);
		
		
	}

}
