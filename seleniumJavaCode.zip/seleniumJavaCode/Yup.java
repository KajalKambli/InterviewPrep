package com.selenium;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
//Get output a2b1c4a3
public class Yup {
	
	public int m1(int y)
	{
		return y;
		
	}
	

	public static void main(String[] args) {
		
		String str="aabcccccaaa";
		
		
	
				
		ArrayList<String>  arr=new ArrayList<String>();
		
		
		int count=1;
		
		StringBuilder sb=new StringBuilder();
		
		for(int i=0;i<str.length();i++) {
			
			
			
			if(i+1<str.length() && str.charAt(i)==str.charAt(i+1))
			{
				count++;
				
				
			}
			
			else
			{
				
				sb.append(str.charAt(i));
				sb.append(count);
				
				count=1;
				
				
			
			}
			
			
			}
		
		System.out.println(sb);
			
		//Convert String array to int array and do addition 
			String[] str1= {"1","2"};
			
			int[] it=Arrays.stream(str1).mapToInt(Integer::parseInt).toArray();
			
			int sm=Arrays.stream(it).sum();
			
			System.out.println("sum of string" +sm);
			
			//Addition of int digit 

			 int i=123;
		        
		       // int sum=0
		        
		       int s= String.valueOf(i).chars().map(Character::getNumericValue).sum();
		       
		       System.out.println(s);
		       
		       //convert int value to String value 
		       
		       int itnum=123;
		       
		       String strvalue=Integer.toString(itnum);
		       String strValue2=String.valueOf(itnum);
		       
		       //convert String to int value .
		       
		       String strvalue3="kajal";
		       
		       int invaluestr=Integer.parseInt(strvalue3);
		       
		       //convert String array to int array 
		       
		       String[] strarr= {"1","2"};
		    
		       int[] itarr=Arrays.stream(strarr).mapToInt(Integer::parseInt).toArray();
		       
		    // convert int array to String Array   
		       
		       int[] itar= {1,2,3};
		       String[] srarr=Arrays.stream(itar).mapToObj(String::valueOf).toArray(String[]::new)
		    		   
		    		   ;
			
	}
		
	}

